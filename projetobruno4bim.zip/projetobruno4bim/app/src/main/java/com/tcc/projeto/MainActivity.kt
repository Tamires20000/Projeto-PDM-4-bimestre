package com.tcc.projeto

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {

    private var num1: Double = 0.0
    private var num2: Double = 0.0
    private var operacao: String = ""
    private var digSegundoNum = false
    private var modoRaiz = false
    private var inputAtual = "0"
    private var historicoTexto = "Nenhum cálculo realizado ainda."

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        androidx.appcompat.app.AppCompatDelegate.setDefaultNightMode(
            androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_NO
        )

        setContentView(R.layout.activity_main)

        val visor = findViewById<TextView>(R.id.resultado)
        val historicoView = findViewById<TextView>(R.id.textViewHistorico)
        val btnHistorico = findViewById<Button>(R.id.btnHistorico)

        historicoView.text = ""

        val b0 = findViewById<Button>(R.id.button0)
        val b1 = findViewById<Button>(R.id.button1)
        val b2 = findViewById<Button>(R.id.button2)
        val b3 = findViewById<Button>(R.id.button3)
        val b4 = findViewById<Button>(R.id.button4)
        val b5 = findViewById<Button>(R.id.button5)
        val b6 = findViewById<Button>(R.id.button6)
        val b7 = findViewById<Button>(R.id.button7)
        val b8 = findViewById<Button>(R.id.button8)
        val b9 = findViewById<Button>(R.id.button9)
        val btnPonto = findViewById<Button>(R.id.btnPonto)

        val btnSoma = findViewById<Button>(R.id.btnSoma)
        val btnSubtracao = findViewById<Button>(R.id.btnSubtracao)
        val btnMultiplicacao = findViewById<Button>(R.id.btnMultiplicacao)
        val btnDivisao = findViewById<Button>(R.id.btnDivisao)
        val btnPorcentagem = findViewById<Button>(R.id.btnPorcentagem)
        val btnRaiz = findViewById<Button>(R.id.btnRaiz)
        val btnResultado = findViewById<Button>(R.id.btnResultado)
        val btnLimpar = findViewById<Button>(R.id.btnLimpar)
        val btnApagar = findViewById<Button>(R.id.btnApagar)

        btnHistorico.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Histórico de Cálculos")
                .setMessage(historicoTexto)
                .setPositiveButton("Fechar") { dialog, _ ->
                    dialog.dismiss()
                }
                .setNeutralButton("Limpar Histórico") { _, _ ->
                    historicoTexto = "Nenhum cálculo realizado ainda."
                }
                .show()
        }

        fun atualizarVisor() {
            if (modoRaiz) {
                visor.text = "√($inputAtual)"
            } else if (!digSegundoNum) {
                visor.text = inputAtual
            } else {
                val simboloOp = if (operacao == "*") "x" else if (operacao == "/") "÷" else operacao
                visor.text = "$num1 $simboloOp $inputAtual"
            }
        }

        fun adicionarDigito(digito: String) {
            if (inputAtual == "0" || inputAtual.contains("Erro")) {
                inputAtual = digito
            } else {
                inputAtual += digito
            }

            if (!modoRaiz) {
                if (!digSegundoNum) {
                    num1 = inputAtual.toDoubleOrNull() ?: 0.0
                } else {
                    num2 = inputAtual.toDoubleOrNull() ?: 0.0
                }
            }
            atualizarVisor()
        }

        b0.setOnClickListener { adicionarDigito("0") }
        b1.setOnClickListener { adicionarDigito("1") }
        b2.setOnClickListener { adicionarDigito("2") }
        b3.setOnClickListener { adicionarDigito("3") }
        b4.setOnClickListener { adicionarDigito("4") }
        b5.setOnClickListener { adicionarDigito("5") }
        b6.setOnClickListener { adicionarDigito("6") }
        b7.setOnClickListener { adicionarDigito("7") }
        b8.setOnClickListener { adicionarDigito("8") }
        b9.setOnClickListener { adicionarDigito("9") }

        btnPonto.setOnClickListener {
            if (!inputAtual.contains(".")) {
                inputAtual += "."
                atualizarVisor()
            }
        }

        fun configurarOperacao(opReal: String) {
            if (operacao.isNotEmpty() && digSegundoNum) {
                btnResultado.performClick()
            }
            operacao = opReal
            digSegundoNum = true
            inputAtual = "0"
            atualizarVisor()
        }

        btnSoma.setOnClickListener { configurarOperacao("+") }
        btnSubtracao.setOnClickListener { configurarOperacao("-") }
        btnMultiplicacao.setOnClickListener { configurarOperacao("*") }
        btnDivisao.setOnClickListener { configurarOperacao("/") }
        btnPorcentagem.setOnClickListener { configurarOperacao("%") }

        btnRaiz.setOnClickListener {
            if (!modoRaiz) {
                modoRaiz = true
                inputAtual = "0"
                visor.text = "√($inputAtual)"
            } else {
                val valor = inputAtual.toDoubleOrNull() ?: 0.0
                if (valor < 0) {
                    visor.text = "Erro: Raiz < 0"
                } else {
                    val res = sqrt(valor)
                    val resFormatado = if (res % 1.0 == 0.0) res.toLong().toString() else res.toString()
                    val expr = "√($valor) = $resFormatado"

                    visor.text = resFormatado
                    if (historicoTexto == "Nenhum cálculo realizado ainda.") {
                        historicoTexto = expr
                    } else {
                        historicoTexto = "$expr\n$historicoTexto"
                    }

                    num1 = res
                    inputAtual = resFormatado
                    modoRaiz = false
                    digSegundoNum = false
                    operacao = ""
                }
            }
        }

        btnApagar.setOnClickListener {
            if (inputAtual.length > 1 && !inputAtual.contains("Erro")) {
                inputAtual = inputAtual.substring(0, inputAtual.length - 1)
            } else {
                inputAtual = "0"
            }

            if (!modoRaiz) {
                if (!digSegundoNum) {
                    num1 = inputAtual.toDoubleOrNull() ?: 0.0
                } else {
                    num2 = inputAtual.toDoubleOrNull() ?: 0.0
                }
            }
            atualizarVisor()
        }

        btnLimpar.setOnClickListener {
            num1 = 0.0
            num2 = 0.0
            operacao = ""
            digSegundoNum = false
            modoRaiz = false
            inputAtual = "0"
            visor.text = "0"
            historicoTexto = "Nenhum cálculo realizado ainda."
        }

        btnResultado.setOnClickListener {
            if (modoRaiz) {
                val valor = inputAtual.toDoubleOrNull() ?: 0.0
                if (valor < 0) {
                    visor.text = "Erro: Raiz < 0"
                } else {
                    val res = sqrt(valor)
                    val resFormatado = if (res % 1.0 == 0.0) res.toLong().toString() else res.toString()
                    val expr = "√($valor) = $resFormatado"

                    visor.text = resFormatado
                    if (historicoTexto == "Nenhum cálculo realizado ainda.") {
                        historicoTexto = expr
                    } else {
                        historicoTexto = "$expr\n$historicoTexto"
                    }

                    num1 = res
                    inputAtual = resFormatado
                    modoRaiz = false
                    digSegundoNum = false
                    operacao = ""
                }
            } else if (operacao.isNotEmpty()) {
                var total = 0.0
                var erro = false

                when (operacao) {
                    "+" -> total = num1 + num2
                    "-" -> total = num1 - num2
                    "*" -> total = num1 * num2
                    "/" -> if (num2 == 0.0) erro = true else total = num1 / num2
                    "%" -> total = (num1 * num2) / 100
                }

                if (erro) {
                    visor.text = "Erro: Divisão por 0"
                } else {
                    val resultadoFormatado = if (total % 1.0 == 0.0) total.toLong().toString() else total.toString()
                    val simboloOp = if (operacao == "*") "x" else if (operacao == "/") "÷" else operacao
                    val expressao = "$num1 $simboloOp $num2 = $resultadoFormatado"

                    visor.text = resultadoFormatado
                    if (historicoTexto == "Nenhum cálculo realizado ainda.") {
                        historicoTexto = expressao
                    } else {
                        historicoTexto = "$expressao\n$historicoTexto"
                    }

                    num1 = total
                    num2 = 0.0
                    inputAtual = resultadoFormatado
                    digSegundoNum = false
                    operacao = ""
                }
            }
        }
    }
}